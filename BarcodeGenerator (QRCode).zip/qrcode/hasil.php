<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="BaGen (Barcode Generator) QR Code Version">
    <meta name="author" content="Hakko Bio Richard">
    <link rel="icon" href="">

    <title>BaGen (Barcode Generator) QR Code Version</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
<?php include "phpqrcode/qrlib.php"; ?>
  <body>

    <div class="container">

      <form class="form-signin">
        <h2 class="form-signin-heading">QR Code Generator</h2>
        <label for="inputData" class="sr-only">InputData</label>
        <center><?php QRcode::png("$_GET[kode]", "png/$_GET[kode].png", "L", 6, 6); ?><?php echo "<img src='png/$_GET[kode].png' /><br/>" ?></center>
        <br />
        <center><h4><?php echo "$_GET[kode]"; ?></h4></center>
        <?php $a = "png/$_GET[kode].png"; ?>
        <a class="btn btn-lg btn-primary btn-block" href="<?php echo "$a" ?>" >Download PNG</a>
      </form>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
